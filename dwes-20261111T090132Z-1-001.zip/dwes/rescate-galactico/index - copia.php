<?php
require "informe.php";

$misiones = [
    ["nombre" => "piwi", "planeta" => "jupiter", "dificultad" => "alta"],
    ["nombre" => "wipi", "planeta" => "marte", "dificultad" => "media"],
    ["nombre" => "chipi", "planeta" => "saturno", "dificultad" => "baja"],
];

function muestraformulario($misiones)  {
    global $planetas;
    foreach ($misiones as $mision) {
        echo "<form action='' method='post'>";
        echo "<label for='nombre'>Nombre:</label>
                <input type='text' name='nombre' value='" . $mision['nombre'] . "'>";
        echo "<label for='planeta'>Planeta:</label>
                <input type='text' name='planeta' value='" . $mision['planeta'] . "'>";
        echo "<label for='dificultad'>Dificultad:</label>
                <input type='text' name='dificultad' value='" . $mision['dificultad'] . "'>";
        echo "<button type='submit'>Resolver</button>";
        echo "</form>";
    }

}


?>  