<?php
//JUAN FEREZ LUCAS- 2 DAW.

require "informe.php";

$misiones = [
    ["nombre" => "piwi", "planeta" => "marte", "dificultad" => "alta"],
    ["nombre" => "wipi", "planeta" => "saturno", "dificultad" => "media"],
    ["nombre" => "chipi", "planeta" => "jupiter", "dificultad" => "baja"],
];
$esvalido=false;

//hago las comprobaciones para ver si me han enviado el formulario y contiene datos para reaprovechar, y si los tengo todos... es válido!
$nombre = isset($_POST['nombre']) ? trim($_POST['nombre']) : '';
$mascota = isset($_POST['mascota']) ? trim($_POST['mascota']) : '';
$nivel = isset($_POST['nivel']) ? $_POST['nivel'] : '';
$planeta = isset($_POST['planeta']) ? $_POST['planeta'] : '';
$planeta = array_key_exists($planeta, $planetas) ? $planeta : "";  //compruebo que el valor recibido esté en array de planetas o lo igualo a cadena vacía
$enviado = isset($_POST['botoncico']);

//comprobruebo que tengo datos y son válidos en las variables 
if ($nombre >0 && $mascota>0 && ($nivel >0) && ($nivel <=100) && $planeta >0){
   // echo "formulario valido";
    $esvalido=true;
        }


//esta función muestra el formulario con 
function muestraformulario($misiones, $nombre, $mascota,$nivel, $planeta, $enviado,$esvalido )  {
     global $planetas;
    // global $nombre;
    // global $mascota;
    // global $nivel;
    // global $planeta;
    // global $esvalido;
        echo "<form action='' method='post'>";
        echo "<label for='nombre'>Nombre del agente:</label>";  //el operador ternario seleeciona entre el valor de la variable dependiendo de si el formulario está vacio para mostrar el mensaje y este ha sido enviado o no
        echo "<input type='text' name='nombre'  value= ' " . (($enviado) ? $nombre : '') .  " ' > ". ((($enviado)&&($nombre=='')) ? 'introduzca el nombre' : '')  ." <br>";
        echo "<label for='mascota'>Nombre de la mascota rescatada</label>";
        echo "  <input type='text' name='mascota' value= ' " . (($enviado) ? $mascota : '') .  " ' > ". ((($enviado)&&($mascota=='')) ? 'introduzca el nombre de la mascota' : '')  ." <br>";
       
        echo "</select>";
        echo "<label for='dificultad'>nivel de energía:</label >";
        echo "<input type='number' name='nivel' value='" . (($enviado) ? $nivel : '') .  "' > ". ((($enviado)&& (($nivel=='') || ($nivel<0) || ($nivel>100))) ? 'introduzca un nivel válido' : '')  ." <br>";
        echo "<br>";
        echo "<label for='planeta'>Planeta</label>";
        echo "        <select name=\"planeta\" >";
        
            foreach ($planetas as $planetilla => $valor ) {
        
         
            echo '<option value="' . $planetilla . '" ' . ((($enviado) && ($planeta == $planetilla)) ? 'selected' : '') . '>' . $planetilla . '</option>';

            }
            echo "</select> <br>";        
        echo "<br>";
        
    
echo "<button name='botoncico' type='submit'>Resolver</button><br>";
echo "</form>";

if ($nombre >0 && $mascota>0 && ($nivel >0) && ($nivel <=100) && $planeta >0){
                        
    $esvalido=true;
        }

}
//su nombre lo indica todo
function calculapeligrosidad ($planetas, $planeta, $nivel){
    return $planetas[$planeta]*10+$nivel;
}

function cuantoriesgo ($nivel){
    if ($nivel < 40) return "BAJA";
    if (($nivel > 39) && ($nivel <80)) return "MEDIA";
    if (($nivel > 79) && ($nivel <120)) return "ALTA";
    return "CRITICA";
}
function nombregalactico ($nombre,$planeta){
return substr($nombre,0,3).strtoupper(substr($planeta,2,3));

}
// -----------------------------------
//mientras no tenga el formulario completo  lo sigo mostrando y viceversa
if ($esvalido ==false){
    echo $esvalido;
    muestraformulario($misiones, $nombre, $mascota,$nivel, $planeta, $enviado, $esvalido );
        }
//muestro el informe de la misión
if ($esvalido) {
    echo "<br><br>";
    echo "<h3>INFORME DE MISIÓN</h3> <hr><br>";
        echo "<br>NOMBRE: ". $nombre;
    echo "<br>Planeta: ". $planeta;
    echo "<br>Nivel: ". $nivel;
    echo "<br>Indice de peligrosidad: ";

    $riesgo= calculapeligrosidad ($planetas, $planeta, $nivel);
    echo $riesgo;
    echo "   ". cuantoriesgo($riesgo). "<br>"; 
    echo "Nombre en clave: ". nombregalactico($nombre,$planeta)."<br><hr>";

    //cero un opjeto con la misión y lo añado al array de misiones, se puede hacer en un solo paso, pero asi queda mas claro
   $objetonuevo = ["nombre" => $nombre, "planeta" => $planeta, "dificultad" => cuantoriesgo($riesgo)];

   array_push($misiones, $objetonuevo);  



}
if ($esvalido) {
// construyo una tabla y muestro las misiones almacenadas junto con la nuestra
echo "<h3>Misiones realizadas</h3>";
echo "<table>
    <thead>
        <tr>
            <th>Nombre</th>
            <th>Planeta</th>
            <th>Dificultad</th>
        </tr>
    </thead>
    <tbody>";
     foreach ($misiones as $mision) {
        echo "
            <tr>
                <td>". $mision['nombre'] . "</td>";
        echo "  <td>". $mision['planeta']. "</td>";
        echo "  <td>". $mision['dificultad']."</td>
            </tr>";
     }
   echo "</tbody>
    </table>";
}
//y esto viene siendo todo.
?>  