<!-- 
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    if (!$_POST['nombre']) {
        echo "debe de introducir un nombre";
        }

        
        $edad   = $_POST['edad'] ?? '';
    if ($edad<16||$edad )
    $edad   = $_POST['edad'] ?? '';
    $email  = $_POST['email'] ?? '';
    exit ();
    
} else {
echo '
    <form id="formulario" action= "index.php" method = "POST">
        
        <input type="text" name ="nombre"> <br>
        <input type="number" name="edad" ><br>
        <input type="email" name="email" ><br>
        <input type="submit" name = "boton" value="enviar">
    </form>
    ';
    }
?> -->

<form enctype=
"multipart/form-data" action=“archivos.php" method=
"POST">
 <input type="hidden" name="MAX_FILE_SIZE" value="30000">
 <input name="sube" type=
"file">
 <button type="submit">Importar archivo</button>
</form>
