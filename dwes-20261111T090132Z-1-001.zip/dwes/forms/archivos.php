<?php
 $dir_subidas = $_SERVER["DOCUMENT_ROOT"].'/uploads/’; 
$fn = $dir_subidas . basename($_FILES['sube']['name’]); 
echo '<pre>’;
// movemos el archivo de su ubicación temporal a la ruta definida
if (move_uploaded_file($_FILES['sube']['tmp_name'], $fn)) {
 echo "El archivo es válido y se subió con éxito.\n";
} else {
 echo "Error al subir el archivo es válido.\n";
}
echo 'Más información:'.print_r($_FILES, true).'</pre>’;

?>