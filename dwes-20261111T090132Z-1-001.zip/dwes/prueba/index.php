<?php
//JUAN FEREZ LUCAS- 2 DAW.

$campos = ["primero", "segundo", "tercero", "cuarto"];

function muestraarray($campos){
    echo "<form action='' method='post'>";
    foreach ($campos as $valor) {
        echo "<input type='checkbox' name='campos[]' value='" . $valor . "'>" . $valor . "</input>";
    }
    echo "<input type='submit' value='Enviar'>";
    echo "</form>";
}

muestraarray($campos);

function muestracheckbox($campos){
    if (isset($_POST['campos'])) {
        $seleccionados = $_POST['campos'];
        
        echo "<h2>Campos seleccionados:</h2>";
        echo "<ul>";
        foreach ($seleccionados as $valor) {
            echo "<li>" . $valor . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<h2>No se han seleccionado campos.</h2>";
    }
}
muestracheckbox($campos);

?>