<?php
// Declaración del array asociativo
$planetas = [
    "jupiter" => "2",
    "marte" => "4",
    "saturno" => "6",
    "urano" => "3"
];
?>  