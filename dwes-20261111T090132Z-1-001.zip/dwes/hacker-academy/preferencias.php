<?php
echo "<h3>Preferencias de color</h3><br>";
echo '
    <form action="" method="post">

<label>Color de fondo</label>
<select name="color">
  <option value="blanco" selected>Blanco</option>
  <option value="verde" >Verde</option>
  
</select>

<input type="submit" name="preferencia" value="Guardar Preferencia"><br>

</form>
    ';

?>