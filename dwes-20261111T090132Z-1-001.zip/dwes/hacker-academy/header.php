<?php
$usuario="juan";   //////////////////////////////////////////////////////////////////
echo '<form action="" method="post">
<input type="submit" name="botoncasa" value="Casa">';


echo '<form action=""method="post">
<input type="submit" name="botoncerrar" value="cerrar sesion">

<label>usuario:'. $usuario .'</label>
</form>';

echo "<h1>Hacker Academy </h1>";
?>