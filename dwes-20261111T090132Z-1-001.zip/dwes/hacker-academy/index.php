
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>
</head>
<body>
<?php
include "header.php";
pideid();





function pideid (){
    echo "<h3>Identificacion del Agente</h3><br>";
    echo '
    <form action="" method="post">

<label>Usuario</label>
<input type="text" name="nombre"><br>
<label>Contraseña</label>
<input type="password" name="contrasena" >
<input type="submit" value="Iniciar sesion">


</form>
    ';

    
}

?>



</body>
</html>

