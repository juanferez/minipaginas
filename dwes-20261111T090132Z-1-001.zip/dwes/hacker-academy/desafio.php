<?php
echo ' <h1>Entrenamiento</h1>

  <form action="" method="post">
    <fieldset>
      <legend>Desafío 1. Contraseñas</legend>
      <p>¿Qué contraseña es más segura?</p>
      <label><input type="radio" name="desafio1" value="a"> 123456</label><br>
      <label><input type="radio" name="desafio1" value="b"> Una frase larga y única</label><br>
      <label><input type="radio" name="desafio1" value="c"> Mi fecha de nacimiento</label><br>
      <button type="submit" name="desafio1">Enviar desafío</button>
    </fieldset>
  </form>

  <form action="" method="post">
    <fieldset>
      <legend>Desafío 2. Phishing</legend>
      <p>¿Qué haces ante un correo sospechoso?</p>
      <label><input type="radio" name="desafio2" value="a"> Abrir sus enlaces</label><br>
      <label><input type="radio" name="desafio2" value="b"> Enviar mi contraseña</label><br>
      <label><input type="radio" name="desafio2" value="c"> Comprobar el remitente y no abrir enlaces</label><br>
      <button type="submit" name="desafio2">Enviar desafío</button>
    </fieldset>
  </form>

  <form action="" method="post">
    <fieldset>
      <legend>Desafío 3. Actualizaciones</legend>
      <p>¿Para qué sirven las actualizaciones de seguridad?</p>
      <label><input type="radio" name="desafio3" value="a"> Para corregir vulnerabilidades</label><br>
      <label><input type="radio" name="desafio3" value="b"> Para sustituir las copias de seguridad</label><br>
      <label><input type="radio" name="desafio3" value="c"> Para evitar cualquier ataque para siempre</label><br>
      <button type="submit" name="desafio3">Enviar desafío</button>
    </fieldset>
  </form>

  <form action="" method="post">
    <p>
      <button type="submit" name="finalizardesafio">Finalizar entrenamiento</button>
    </p>
  </form>
  </form> ';
  ?>