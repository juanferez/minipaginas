<?php
 if (isset ($_POST['boton'])){
$nombre = isset ($_POST['nombre']) ?? $_POST['nombre'] ;
 $apellidos = isset ($_POST['apellidos']) ?? $_POST['apellidos']; 
 $usuario= isset ($_POST['usuario']) ?? $_POST['usuario']; 
 $correo= isset ($_POST['correo']) ?? $_POST['correo'];
 $telefono= isset ($_POST['telefono']) ?? $_POST['telefono'];
 $direccion= isset ($_POST['direccion']) ?? $_POST['direccion'];
  $contrasena= isset ($_POST['contraseña']) ?? $_POST['contraseña'];
  $esvalido = ($nombre >0) &&   ($apellidos >0) && ($usuario >0) && ($correo >0) && ($telefono >0) && ($direccion >0) && ($contrasena >0) ;
 
  }
 
  if ($esvalido){
  $archivo = fopen('datos.csv', 'w');  
  $linea = [$nombre, $apellidos, $usuario, $correo, $telefono,$direccion,$contrasena];
        fputcsv($archivo, $linea);
        fclose($archivo);
  }
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    
    <form action="" id="formulario" method="post">
         <label for="nombre">Nombre</label>
         <input type="text" id="nombre" name="nombre" >
         <label for="apellidos">apellidos</label>
         <input type="text" id="apellidos" name="apellidos" >
         <label for="usuario">usuario</label>
         <input type="text" id="usuario" name="usuario" >
         <label for="email">correo</label>
         <input type="email" id="correo" name="correo" >
         <label for="contraseña">contraseña</label>
         <input type="text" id="contraseña" name="contraseña" >
         

         <input type="submit" name ="boton" value="enviar">
       </form>
    <?php
    
    ?>
</head>
<body>

</body>
</html>

