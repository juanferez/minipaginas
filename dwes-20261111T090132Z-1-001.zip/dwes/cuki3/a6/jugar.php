<?php
    session_start();
    if (isset($_POST['enviar'])){
        $_SESSION['nombre'] = $_POST['nombre'] ?? '';
        if (!isset($_POST['numero'])){
            echo "No has enviado ningún número";
            exit();
        }
        $numero = $_POST['numero'];
        $aleatorio = random_int(1,5);
        if ($numero == $aleatorio)
            echo "¡Has acertado!";
        else
            echo "¡Has perdido! Vuelve a intentarlo";

        $partida['numUsuario'] = $numero;
        $partida['numAleatorio'] = $aleatorio;
        $partida['acierto'] = ($numero == $aleatorio) ? "GANA" : "PIERDE";

        $_SESSION['partidas'][] = $partida;
    }
?>

<a href="index.php">Vuelve a intentarlo</a>
