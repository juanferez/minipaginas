<?php
    session_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form method = "post" action = "jugar.php">
        <?php
            if (!isset($_SESSION['nombre']))
                echo '<input type = "text" placeholder = "nombre" name = "nombre"><br>';
            else
                echo "Hola, " . $_SESSION['nombre'] . "<br>";
        ?>
        <input type = "number" name = "numero" min = "1" max = "5"><br>
        <button type = "submit" name = "enviar"> Enviar </button>
    </form>

    <a href = "finalizar.php"> Finalizar </a>
</body>
</html>