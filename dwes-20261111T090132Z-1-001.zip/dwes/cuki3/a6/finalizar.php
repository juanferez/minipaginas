<?php
    session_start();
    if (!isset($_SESSION['nombre']))
        header("Location: index.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
        $nombre = $_SESSION['nombre'];

        echo $nombre . "Estas son tus partidas: <br>";
        $partidas = $_SESSION['partidas'];
        $i=1;
        foreach($partidas as $partida){
            echo "Partida $i: numero elegido: " . $partida['numUsuario'] . ", numero aleatorio: " . $partida['numAleatorio'] . " " . $partida['acierto'] . "<br>";
            $i++;
        }

        $_SESSION[] = 0;
        if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', [
        'expires' => time() - 3600, 'path' => $p['path'],
        'domain' => $p['domain'], 'secure' => $p['secure'],
        'httponly' => $p['httponly']]);
        }
        session_destroy();


    ?>
    <a href = "index.php"> Volver a empezar </a>

</body>
</html>