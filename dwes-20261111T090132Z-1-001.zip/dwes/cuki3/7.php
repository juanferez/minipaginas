<?php
session_start();

$nombre = isset($_SESSION['nombre']) ?? $_SESSION['nombre'];
if ((!isset($nombre)) && isset($_POST['nombre'])) {
    $nombre = $_POST['nombre'];

}
else $nombre="";


$ale = rand(0,5);  //la primera vez será tontesco, pero me gusta hacer estas cosas al principio
$numero = (isset ($_POST['numero'])) ? $_POST['numero'] : '' ;
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="" method="post">
<label for="nombre">Nombre</label>
<input type="text" name="nombre" id="nombre">
<label for="numero">Numero</label>
<input type="number" name="numero" id="numero" min="0" max="5">
<input type="submit" value="Jugar" name="botonjugar">
</form>
<hr>
<form action="" method="get">
<input type="submit" value="Finalizar" name="botonfinalizar">
</form>

</body>
</html>

