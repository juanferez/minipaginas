<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$json= $_COOKIE['preferencias'] ?? '{}';
$preferencias= json_decode($json, true);

$nombre = isset($_COOKIE['nombre']) ? $_COOKIE['nombre'] : "" ;
$color = isset($_COOKIE['color']) ? $_COOKIE['color'] : "" ;
echo $nombre;

echo $color;
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : "" ;
$color = isset($_POST['color']) ? $_POST['color'] : "" ;
$preferencias = [$nombre,$color];
$json = json_encode($preferencias);
setcookie('preferencias', $json, ['path' => '/']);
$json = json_encode($nombre);
setcookie('nombre', $json, ['path' => '/']);
$json = json_encode($color);
setcookie('color', $json, ['path' => '/']);

echo "<style>background-color: ". $color . " ;</style>";

?>
<form action="" id="formulario" method="POST">
     <label for="nombre">Nombre</label>
     <input type="text" id="nombre" name="nombre" >
     <label for="color"></label>
     <select name="color" id="color" >
       <option value="red">rojo</option>
       <option value="blue">Azul</option>
       <option value="green">verde</option>

     </select>
     
     <input type="submit" name="boton" value="Submit">
   </form>
<?php
// $nombre = isset($_COOKIE['nombre']) ? $_COOKIE['nombre'] : "" ;
// $color = isset($_COOKIE['color']) ? $_COOKIE['color'] : "" ;
// $preferencias = [$nombre,$color];
// $json = json_encode($preferencias);
// setcookie('preferencias', $json, ['path' => '/']);

echo "<style>body { background-color: " . $color . "; }</style>";

?>

</body>
</html>

