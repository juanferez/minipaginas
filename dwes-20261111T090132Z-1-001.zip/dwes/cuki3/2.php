<!-- Fichero con pares: id_producto;nombre_producto;precio
index.php
● Mostrar productos y permitir añadir indicando la cantidad.
● El carrito se mantendrá durante 7 días.
Botón a ver_carrito.php
● Quitar artículo y vaciar el carrito.
● Al mostrar el carrito, buscar en el catálogo del servidor los precios reales. 
Muestra el precio por producto. El total por producto. El total de la compra.
Botón a añadir.php:
Convertir el arrayde identificadores/cantidades a JSON.
Crea o actualiza la cookie -->

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<?php
$idproducto =['1' => 'leche','2' => 'cacao','3' => 'avellana','4' => 'azucar'];
$precio = ['1' => 4.95,'2' => 3,'3' => 6,'4' => 3.21];

foreach ($idproducto as $clave => $valor){
echo "<p>.- ". $valor ." ----> ". $precio [$clave] ." </p>";
}


?>

</body>
</html>

