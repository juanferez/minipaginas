<?php
if (!isset($_POST['enviar'])){
    echo "<h1>no deberías de estar aquí</h1>";
}
if (!isset($_POST['nombre'])){
    echo "<h1>no has introducido el nombre</h1>";
    }

if (!isset($_POST['email']) || (filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) ){
    echo "<h1>no has introducido el nombre</h1>";
    }

?>