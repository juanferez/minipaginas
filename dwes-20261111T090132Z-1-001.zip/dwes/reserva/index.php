<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
    <form action="reserva.php" id="formulario" method="post">
         <label for="nombre">Nombre</label>
         <input type="text" id="nombre" name="nombre" >
         <label for="correo">Nota</label>
         <input type="email" id="email" name="email" >
         <label for="fechadeentrada">Fecha de entrada</label>
        <input type="date" name="fechadeentrada" id="fechadeentrada">
        <input type="date" name="fechadesalida" id="fechadesalida">
        
         
         <input type="submit" name="enviar" value="Submit">
       </form>





</body>
</html>

