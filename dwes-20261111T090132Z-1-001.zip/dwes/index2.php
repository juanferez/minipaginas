<?php
$resultado = 5;
$tipo = gettype($resultado);
echo "Resultado vale: $resultado y es de tipo $tipo \n";//pondrá una que resultado vale 0.00 y el tipo es float
echo "<br>";  
$resultado = 5.5;
$tipo = gettype($resultado);
echo "Resultado vale: $resultado y es de tipo $tipo \n";//pondrá una que resultado vale 0.00 y el tipo es float
echo "<br>";  
echo "<br>";  


$resultado = 5.5;
$tipo = gettype($resultado);
echo "Resultado vale: $resultado y es de tipo $tipo \n";//pondrá una que resultado vale 0.00 y el tipo es float
echo "<br>";  
$resultado = (int)$resultado;
$tipo = gettype($resultado);
echo "Resultado vale: $resultado y es de tipo $tipo \n";//pondrá una que resultado vale 0.00 y el tipo es float
echo "<br>";  
echo "<br>";  
$parametro="";
$nombre= "Juan";
$apellidos="Perro";
$direccion= " Su calle";
$codigopostal= "30.170";
$localidad= "Mula";
$provincia = "Murcia";

function muestratipo($variable){
    echo "<tr>";
    echo "<td>";
        echo $variable;
    echo "</td>";
    echo "<td>";
        global $$variable; //global $nombre
        echo $$variable;
        echo "</td>";
         echo "<td>";
    echo gettype($variable);
        echo "</td>";

    echo "</tr>";
    }
$parametro="nombre";

echo "<table>" ;
muestratipo($parametro);
echo "</table>";


$frutas = ["nombre", "apellidos", "direccion"];

foreach ($frutas as $fruta) {
    muestratipo($fruta);
}
?>