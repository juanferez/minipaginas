<?php
$resultado = 0.00;
$tipo = gettype($resultado);
echo "Resultado vale: $resultado y es de tipo $tipo \n";//pondrá una que resultado vale 0.00 y el tipo es float
echo "<b>";  
$resultado = "Cero";
$tipo = gettype($resultado);
echo "y ahora vale: $resultado y es de tipo $tipo\n";   // pondrá que resultado vale "cero" y el tipo es string

echo "<b>";  

?>

<h2> ejercicio 2</h2>
<?php 
$resultado = 0;
$tipo = gettype($resultado);
echo "Resultado vale: $resultado y es de tipo $tipo\n";    //pondrá que vale 0 y es de tipo integer
echo "<b>";     
$resultado2 = (double)$resultado;
$tipo = gettype($resultado2);
echo "y Resultado2: $resultado2 y es de tipo $tipo\n";   
$tipo = gettype($resultado);
echo "y Resultado vale: $resultado y es de tipo $tipo";

?>