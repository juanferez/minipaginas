<!doctype html>
<html lang="es">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>libreria</title>
    <!-- <link rel="stylesheet" href="./css/styles.css" /> -->
</head>

<?php include "header.php";

?>
<!-- idades a 8 euros, libro «1984» con 1 unidad a 12 euros y libro «Matilda» con 2 unidades a 11 euros. -->
<?php
define("NOMBRE_LIBRERIA", "Librería Letras y Tinta");
define("IVA", 0.21);
$clienta = "LUCIA PEREZ";
$libro1 = "El principito";
$unidadeslibro1 = 2;
$preciolibro1 = 8;
$libro2 = "1984";
$unidadeslibro2 = 1;
$preciolibro2 = 12;
$libro3 = "Matilda";
$unidadeslibro3 = 2;
$preciolibro3 = 11;
?>
<h2>Resumen de compra</h2>

<h3> <?= $clienta ?> </h3>

<table>
    <th>Resumen de compra</th>
    <tr>
        <td>Libro </td>
        <td> Unidades </td>
        <td>Precio unitario </td>
        <td>Importe </td>
    </tr>
    <?php
    echo "  
<tr>
<td> $libro1</td> <td>$unidadeslibro1</td> <td>$preciolibro1 </td> <td> " . ($preciolibro1 * $unidadeslibro1) . " </td>
</tr>
<tr>
<td> $libro2</td> <td>$unidadeslibro2</td> <td>$preciolibro2 </td> <td> " . ($preciolibro2 * $unidadeslibro2) . " </td>
</tr>
<tr>
<tr>
<td> $libro3</td> <td>$unidadeslibro3</td> <td>$preciolibro3 </td> <td> " . ($preciolibro3 * $unidadeslibro3) . " </td>
</tr>

"
                                                                                                                       ?>
</table>
<p>Subtotal</p>


<?php include "footer.php";

?>