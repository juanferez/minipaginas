datos = []

document.querySelector("#formulario").addEventListener("submit",(ev)=> {
    ev.preventDefault();
    
    const objeto = {
        nombre: document.getElementById("nombre").value,
        nota:Number(document.),
    }

});