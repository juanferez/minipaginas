<h1>Librería Letras y Tinta</h1>
<nav>
     <p> Inicio Catálogo Contacto     </p>
</nav>